#include <xc.h>
#include "user.h"
void initAdc1(void)
{
    
 ANSELAbits.ANSA0 = 1; // Ensure AN0/RA0 is analog  
/* Initialize and enable ADC module */
 // Enable simultaneous sampling and auto-sample
AD1CON1bits.ASAM=1;         //sample auto start
AD1CON1bits.SSRC=7;            //auto convert
AD1CON1bits.FORM=0b0;      //t uint format
//AD1CON1bits.FORM=0b01;      //int format
AD1CON1bits.SIMSAM=0;       //simultaneos
//AD1CON1bits.AD12B=1;
AD1CON2bits.BUFM= 0;        //starts filling buffer
AD1CON2bits.ALTS= 0;        //Always MUXA input
AD1CON2bits.VCFG=0;         //REFH=+Vcc/REFL=0V
//AD1CON2bits.CHPS=0;         //CONVERTS CH0
AD1CON2bits.CHPS=1;         //CONVERTS CH0 and CH1
AD1CON2bits.CSCNA=0;        //no Scan CH0+ input
//AD1CON2bits.SMPI=0b01111;       //int 1x to 16
AD1CON2bits.SMPI=0b1 ;      //int 1x to 2
AD1CON3bits.ADRC=1;         //RC clock
AD1CON3bits.SAMC=3;         //sampl. per.
AD1CON3bits.ADCS=1;         //conv. per.
AD1CHS0bits.CH0SA=6;       //AN6 input select
AD1CHS0bits.CH0NA=0;       //REFL
AD1CHS123bits.CH123SA=1;       //CH1=AN3....
AD1CHS123bits.CH123NA=0;       //REFL
AD1CSSL= 1;     //AN1
AD1CON4 = 0x0000;
AD1CON1bits.ADON = 1;
//Delay_us(20);
}

void initComp(void)
{
     _CNIF=0;
     //  IEC1bits.CNIE= 1;
     IEC1bits.CMIE= 1;
     ANSELAbits.ANSA1=1;
     ANSELBbits.ANSB0=1;
     ANSELBbits.ANSB1=1;
     ANSELBbits.ANSB2=1;
     ANSELBbits.ANSB3=1;
     ANSELCbits.ANSC0=1;
     ANSELCbits.ANSC1=1;
     ANSELCbits.ANSC2=1;
    //pull ups
     /*
    CNPUAbits.CNPUA1=1;
    CNPUBbits.CNPUB0=1;
    CNPUBbits.CNPUB1=1;
    CNPUBbits.CNPUB2=1;
    CNPUBbits.CNPUB3=1;
    CNPUCbits.CNPUC0=1;
    CNPUCbits.CNPUC1=1;
    CNPUCbits.CNPUC2=1;
      * */
    
  // CVRCONbits.CVRSS= 1;       //CVREF+ voltage source
 //   CVRCONbits.CVR=2;          //set ref voltage (for COMP-)
    CVRCONbits.CVREN=1;        //power on
    CVRCONbits.CVRR=1;         //0..2/3Vref
   // CVRCONbits.CVR1OE= 1;//t
    
    CM2CONbits.CPOL=1;       //output inverted
  //  CM2CONbits.CREF=1;       //CVREF +input //t
  //  CM2CONbits.CREF=0;       //C2IN1 +input 
    CM2CONbits.CCH=0;        //C2IN1- input 
  //  CM2CONbits.EVPOL=3;    //trigger HL, LH
    CM2CONbits.COE=1;       //out enable !t
    CM2CONbits.CON=1;       //comp. enable  
    CM2FLTRbits.CFLTREN=1;      //CM2 filter enable
    CM2FLTRbits.CFDIV=0b01;   //CM2 filter delay
  //  RPOR2bits.RP38R = 0b011001;// output CM2
    RPOR6bits.RP57R = 0b011001;//!t debug output CM2
     
 
    CM1CONbits.CPOL=1;       //output inverted
  //  CM1CONbits.CREF=1;          //CVREF +input //t
    //CM1CONbits.CREF=0;          //C1IN+ +input 
    CM1CONbits.CCH=0;          //C1IN1- input 
  //  CM1CONbits.EVPOL=3;    //trigger HL, LH
    CM1CONbits.COE=1;       //out enable !t
    CM1CONbits.CON=1;       //comp. enable 
    CM1CONbits.OPMODE=0;
    CM1FLTRbits.CFLTREN=1;      //CM1 filter enable
    CM1FLTRbits.CFDIV=0b01;   //CM1 filter delay
  //  RPOR1bits.RP37R = 0b011000;// (LED7)output CM1
    RPOR6bits.RP56R = 0b011000;//!t debug (LED7)output CM1
    
    //*
    CM4CONbits.CPOL=1;       //output inverted
    CM4CONbits.CREF=1;          //CVREF +input 
   // CM4CONbits.CREF=0;          //C4IN1+ +input 
    CM4CONbits.CCH=1;          //AN3->C4IN1- input 
    CM4CONbits.EVPOL=3;    //trigger HL, LH
   // CM4CONbits.COE=1;       //out enable !t
    CM4CONbits.CON=1;       //comp. enable 
    CM4FLTRbits.CFLTREN=1;      //CM4 filter enable
    CM4FLTRbits.CFDIV=0b01;   //CM4 filter delay
//    RPOR1bits.RP37R = 0b011011;// output CM4    
   // RPOR4bits.RP42R = 0b011011;// output CM4  
   //*/ 
  //  ANSELBbits.ANSB1 = 0; // Ensure RB1 is digital input
 //   _CNPUB1= 1; 
    
    CM3CONbits.CPOL=1;       //output inverted
    CM3CONbits.CREF=1;          //CVREF +input 
    //CM3CONbits.CREF=0;          //C3IN1+ +input 
    CM3CONbits.CCH=0;          //C3IN1- input 
    //CM3CONbits.EVPOL=3;    //t trigger HL, LH
    CM3CONbits.COE=1;       //out enable !t
    CM3CONbits.CON=1;       //comp. enable 
    CM3FLTRbits.CFLTREN=1;      //CM3 filter enable
    CM3FLTRbits.CFDIV=0b01;   //CM3 filter delay
    RPOR1bits.RP36R = 0b011010;// output CM3   
}

void __attribute__((interrupt, no_auto_psv)) _CM1Interrupt(void)
{      
    QEI1CONbits.PIMOD= 3;  //null counter  by 1.Index after Home 
 //  LED4= _C2OUT;
//   LED6= _C1OUT;
   LED5= _C4OUT;//t
   _RB14 = _C4OUT;//t
//   _RB10= _C4OUT;//t
  //   _RC9= _C4OUT;//t
  // LED5= _RB1;//_HOME;
  // LED7= _C3OUT;//t
   //CM2CONbits.CEVT=0;
  // CM1CONbits.CEVT=0;
   CM4CONbits.CEVT=0;
  // CM3CONbits.CEVT=0;
   IFS1bits.CMIF  = 0;			// Clear interrupt    
}

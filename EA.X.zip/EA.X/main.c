
/**
  Section: Included Files
*/
#include "mcc_generated_files/system.h"
#include "user.h"
#include "analog.h"
#include "qei.h"
#include "SPI.h"
#include "uart1Drv.h"
#include "uart2Drv.h"
#include "interf.h"
#include <stdio.h>
#include <stdlib.h>
#define HOME _RB14

extern uf UF;
long int dla,clc,claold=0;//t
dhl ala,cla;
int k,ui,sect;
signed int douta;
int *pread,iread, result;
int r;
float fa;
float af;
int NMAX;
float slope[FLASHI];

void initIO(void)
{
     ANSELA=ANSELB=ANSELC=0;//t
     
    _TRISA10= 0;     //enable LED101
    _TRISA7= 0;     //enable LED102
    _TRISB14= 0;     //enable LED103
 //   _TRISB15= 0;    //enable LED104
     _CNPDB15= 1;     //LED104 pull down
    _TRISA2= 0;    //enable LED4
    _TRISA3= 0;    //enable LED6
    _TRISA8= 0;    //enable LED5
    _TRISB4= 0;    //enable LED7
    _CNPUB9= 1;     //alarm pull up
  //  CNENBbits.CNIEB9=1;// ALARM inputchange int
   // CNENBbits.CNIEB5=1;// prog. data change inp.//t
   // CNENBbits.CNIEB6=1; // prog. clock change inp.//t
   
    
}

//Init T1 timer				// input filter timer(also for  scanning coordinates samples)
void initT1(void)
{
 TMR1 = 0;
 PR1 = 1000;				//1000pulses divide 20kHz  to 20Hz
 T1CONbits.TCKPS = 3;		//256   PRESCALLER 
 //T1CONbits.TCKPS = 0;		//1   PRESCALLER 
 T1CONbits.TON = 1;		// turn on timer 1 
 _T1IF=0;
} 

//Init T2 timer				// input filter timer(also for  scanning coordinates samples)
void initT2(void)
{
 TMR2 = 0; 
 PR2 = 0X1FFF;				//1000pulses divide 20kHz  to 20Hz
 T2CONbits.TCKPS = 3;		//256   PRESCALLER 
 T2CONbits.TON = 1;		// testturn on timer 1 
 _T2IF=0;
} 

//Init T3 timer				// input filter timer(also for  scanning coordinates samples)
void initT3(void)
{
 TMR3 = 0;
 //PR3 = 1000;				//1000pulses divide 20kHz  to 20Hz
 PR3 = 0x0fff;				//test
 T3CONbits.TCKPS = 3;		//256   PRESCALLER 
 T3CONbits.TON = 1;		// turn on timer 1 
 _T3IF=0;
} 

unsigned int countdac(void)
{
 unsigned int dret=0;   
 int d;
 sect=0;
 cla.L= POS1CNTL; 
 cla.H= POS1CNTH;
 //if(cla.D < claold) F.CCW=1;                        //set CCW direction of encoder
// else if(cla.D > claold) F.CCW=0;                   //set CW direction of encoder
// claold= cla.D;
 clc=cla.D;
 while((clc >= inkr[sect])&& (sect<NP))                         //search actual position sector of encoder
 {
     sect++;
 }
 
 //if((dinkr[sect] !=0)&&(!DIP1 || !F.CCW))           //enable new calculation of output
 {    
  if((sect==0)||(sect==NP))
    dret=0; 
  else                              //in front of output peak
  {
     d= (unsigned int)(clc - inkr[sect-1]);
     douta= (signed int)(slope[sect-1]*d);  
     dret= voltr[sect-1] + douta;
  }  
 } 
 
 //if((sect==0)||(sect==NMAX))
 //  dret=0;   
     /*
 else if((inkr[sect] > inkr[sect-1])&&(!DIP1 || !F.CCW))           //enable new calculation of output
 {
     d= (unsigned int)(clc - inkr[sect-1]);
     douta= (signed int)(slope[sect-1]*d);  
     dret= voltr[sect-1] + douta; 
 } 
       */
 return dret ;
}

void genslope(void)
{ float fd;
    if((NP > 1) && (NP < NUMAX))
    {
           for(ui=0; ui< NP-1; ui++)
            { fd= (float)(inkr[ui+1]-inkr[ui]);
               if(fd !=0)
               {
                      af= (float)(voltr[ui+1]-voltr[ui])/fd;
                      slope[ui]= af;
               }
               else
                      slope[ui]=0;
            }
    }
}

/*
                         Main application
 */
int main(void)
{
    // initialize the device
    SYSTEM_Initialize();
     TMR1=0;     //pause
    _T1IF=0;
    PR1=0xffff;
    T1CONbits.TON = 1;	
    while(!_T1IF)
    _T1IF=0;
    initIO();
    InitFEPROM((long int * )inkrpar,(long int *) voltrpar);  //Init FEPROM
    initComp();
    initQei();
    initSPI();
    DAC(CONTROL,*dacontrol);
    initAdc1();
    set_encod(*pencod); 
    NP=(int)inkrpar[0];
    genslope();
    initT1();
    initT2();
    initT3();
    cfgUart1();
    cfgUart2();
    while (1)
    {
        // Add your application code
            __asm__("clrwdt");
         LED4= _C2OUT;
         LED6= _C1OUT;
         
         dao=countdac();
         readreg=DAC(DATA,dao);
          interf();
        if(UF.Creq)
        {
            UF.Creq=0;
            *inkrpar=NP;
            WriteFEPROM((long int * )inkrpar,(long int * ) voltrpar);//t
            /*
            for(ui=0; ui< NP-1; ui++)
            {
                      af= (float)(voltr[ui+1]-voltr[ui])/(float)(inkr[ui+1]-inkr[ui]);
                      slope[ui]= af;
            }
             * */
            genslope();
        }
        if(_T3IF)
        {
          _T3IF=0;
     
        }//t
          
    }
    return 1; 
}
/**
 End of File
*/


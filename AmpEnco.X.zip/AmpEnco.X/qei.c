#include <xc.h>
#include "user.h"

void initQei(void)
{
    RPINR14bits.QEA1R= 56;//debug
  //  RPINR14bits.QEA1R= 37;
    RPINR14bits.QEB1R= 57;//debug
  //   RPINR14bits.QEB1R= 38;
    RPINR15bits.INDX1R= 36;
    RPINR15bits.HOME1R= 33;//42;//t
    QEI1CONbits.QEIEN=1;//ENABLE qei
    QEI1CONbits.PIMOD= 3;  //null counter  by 1.Index after Home 
    POS1CNTH=0;
    POS1CNTL=0;
    
}


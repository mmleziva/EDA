
//#include <p33EP128MC504.h>
#include <xc.h>
#include "SPI.h"
#include "user.h"

int nsb,datpre,datmem, *help;
unsigned char adpre;
flags Flags;
contr Control;
config Config;
whl Data,Gain,Zero,Status, Sel,  Readat;
char  inb;


void cfgSpi1Master(void)
{
// Configure SPI1CON register to the following
// ?	Idle state for clock is a low level (SPI1CON1bits.CKP=0)
// ?	Data out on Active to Idle Edge (SPI1CON1bits.CKE=1)
// ?	16-bit data transfer mode (SPI1CON1bits.MODE16=1)
// ?	Enable Master mode (SPI1CON1bits.MSTEN=1)
// ?	Set Primary Pre-scalar for 1:1 ratio (SPI1CON1bits.PPRE=0b11)
// ?	Set Secondary Pre-scalar for 1:1 ratio (SPI1CON1bits.SPRE=0b111)
// ?	Enable SDO output (SPI1CON1bits.DISSDO=0)
// ?	Enable SCK output (SPI1CON1bits.DISSCK=0)
         //SPI1CON1bits.MODE16=1;
         SPI1CON1bits.CKP=0; 		//sample on rising edge of SCK
	     SPI1CON1bits.CKE=1;        //
         SPI1CON1bits.MSTEN=1;
         SPI1CON1bits.SPRE=0b111;    //1:1 sec. prescale
	     SPI1CON1bits.PPRE=0b10;     //prim. prescale 4:1
        // SPI1CON1bits.PPRE=0b01;     //prim. prescale 16:1
         SPI1CON1bits.DISSDO=0;
	     SPI1CON1bits.DISSCK = 0;
        // SPI1CON2bits.FRMPOL = 1;//polarity high
        // SPI1CON2bits.FRMDLY = 0;//precedes
 //        SPI1CON2bits.FRMEN = 1; //frame enabled //!t
         // ?	Enable SPI module (SPI1STATbits.SPIEN=?)
         SPI1STATbits.SISEL=5;      //interrupt after transmitting
         SPI1STATbits.SPIEN=1;
 	   //  _SPI1IE  = 1;			//t Enable SPI1 interrupt
   }


inline void initSPI(void)
{
    TRISBbits.TRISB7=0; //LATCH output
    TRISBbits.TRISB8=0; //CLR output
    CLR= 0;
    cfgSpi1Master();   
}

unsigned int DAC(unsigned char adreg,unsigned int datreg)
{   
    _SPI1IF=0;
    SPI1BUF= adreg;
    Sel.W= datreg;
    while(!_SPI1IF);
    _SPI1IF=0;
    adpre= SPI1BUF;
    SPI1BUF=Sel.H;
    LATCH=0;
    while(!_SPI1IF);
    _SPI1IF=0;
    Sel.H= SPI1BUF;
    SPI1BUF=Sel.L;
    while(!_SPI1IF);
    _SPI1IF=0;
    Sel.L = SPI1BUF;
    LATCH=1; 
    if(adreg==READ)
    {
       SPI1BUF= 0;
       Sel.W= NOP;
       while(!_SPI1IF);
       _SPI1IF=0;
       adpre= SPI1BUF;
       SPI1BUF=Sel.H;
       LATCH=0;
       while(!_SPI1IF);
       _SPI1IF=0;
       Sel.H= SPI1BUF;
       SPI1BUF=Sel.L;
       while(!_SPI1IF);
       _SPI1IF=0;
       Sel.L = SPI1BUF;
       LATCH=1;  
    }
    return Sel.W;
}
//

/*
void initDAC(unsigned int contr,unsigned int config)
{
    initSPI();
  //  Control.RANGE= 0b101;           //4...20mA
    Control.RANGE= 1;           //0...10V
    Control.OUTEN= 1;
    *help=DAC(CONTROL,contr);
    Flags.SOK =1;
} 
*/


// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef XC_HEADER_TEMPLATE_H
#define	XC_HEADER_TEMPLATE_H

#include <xc.h> // include processor files - each processor file is guarded. 
#include "feprom.h"

#define NUMAX 12
void interf(void);
void set_encod(unsigned int senc);
extern dhl steps;
extern long int  inkrpar[FLASHI];
extern long int  voltrpar[FLASHI];
extern long int * const inkr,* const voltr;//t
extern unsigned int ax,NP;
extern unsigned int dao,dacont, readreg, rat;
extern unsigned int  *const pencod, *const dacontrol, *const daconfig;
extern compar comp;
extern int n,m;


#endif	/* XC_HEADER_TEMPLATE_H */


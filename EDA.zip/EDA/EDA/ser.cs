﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.Ports;

namespace EDA
{

    struct ser
    {
        static string[] ins = { "C", "R", "M", "P", "V", "A" };
        static string[] insad = { "G", "H", "I", "J", "K", "T","Q","S","Z","W" };
        static string[] insec = { "X", "Y"};
        public static StringBuilder  sb;
        static string sa;
        static char bi;
        static bool BB = false, BLOCK = false;
        static int nums = 0;
        static bool ALPHA = false;
        public static bool BOPEN = false;
        public static int n;
        public static string[] ports;
        public static SerialPort serial;
        public static Queue<string> inser = new Queue<string>(100);
        public static Queue<string> inserad = new Queue<string>(100);
        public static Queue<string> inserec = new Queue<string>(100);
        public static void Iniser()
        {

            serial = new SerialPort();
            serial.DataReceived += new SerialDataReceivedEventHandler(ReadIn);
            ports = SerialPort.GetPortNames();
            n = ports.Length - 1;

            serial.PortName = ports[n];
            serial.BaudRate = 115200;   //t            
            if (!serial.IsOpen)
            {
                serial.Open();
            }
            sb = new StringBuilder();
            //BOPEN = true;
        }
        public static void Getportnames()
        { 
         ser.ports = SerialPort.GetPortNames();
        }

        private static bool Ishex(char c)
        {

            return (Char.IsDigit(c) || (( c >= 'a') && (c <= 'f'))|| ((c >= 'A') && (c <= 'F'))||(c == '.')) ;
        }
        

        private static void ReadIn(object sender, SerialDataReceivedEventArgs ex)
        {
            try
            {
                if(serial.IsOpen)
                {
                    while (serial.BytesToRead > 0)
                    {
                        bi = (char)serial.ReadChar();
                        if (bi != '\0')
                        {
                            if (!BLOCK)
                            {

                                if (!ALPHA)
                                {
                                    ALPHA = Char.IsLetter(bi);
                                    if (!ALPHA) BLOCK = true;
                                }
                                else
                                {
                                    if (sa == "")
                                        sa = sb.ToString();
                                    // BB = Char.IsDigit(bi);
                                    BB = Ishex(bi);
                                    if (BB)
                                    {

                                        nums++;
                                    }
                                    else { if (nums > 0) BLOCK = true; }
                                }
                                if (!BLOCK)
                                {

                                    sb.Append(bi);
                                }
                            }
                        }
                        else
                        {
                            if (ALPHA && !BLOCK && (nums > 0) && (nums < 12))
                            {
                                if (ins.Contains(sa))
                                    // if(Cont(ins, sa.ToString()))        //ins contain sa
                                    ser.inser.Enqueue(sb.ToString());
                                else

                                    //if (Cont(insad, sa.ToString()))
                                    if (insad.Contains(sa))
                                    ser.inserad.Enqueue(sb.ToString());
                                else
                                    if (insec.Contains(sa))
                                    ser.inserec.Enqueue(sb.ToString());
                            }

                            sb.Clear();
                            sa = "";
                            BLOCK = false;
                            ALPHA = false;
                            nums = 0;
                        }
                    }
                }
            }

            catch (Exception e)
            {
                System.Windows.MessageBox.Show(e.ToString());

            }
        }
        public static void serialWrite(string s)
        {
            try
            {
                if ((BOPEN) && (ser.serial.IsOpen == true))
                    ser.serial.WriteLine(s);
            }
            catch (Exception e)
            {
                System.Windows.MessageBox.Show(e.ToString());
            }
        }
    }

}

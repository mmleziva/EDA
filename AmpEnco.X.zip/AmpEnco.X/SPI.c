
//#include <p33EP128MC504.h>
#include <xc.h>
#include "SPI.h"
#include "user.h"

int nsb,datpre,datmem, *help;
unsigned char adpre;
flags Flags;
contr Control;
config Config;
whl Data,Gain,Zero,Status, Sel,  Readat;
char  inb;


void cfgSpi1Master(void)
{
// Configure SPI1CON register to the following
// ?	Idle state for clock is a low level (SPI1CON1bits.CKP=0)
// ?	Data out on Active to Idle Edge (SPI1CON1bits.CKE=1)
// ?	16-bit data transfer mode (SPI1CON1bits.MODE16=1)
// ?	Enable Master mode (SPI1CON1bits.MSTEN=1)
// ?	Set Primary Pre-scalar for 1:1 ratio (SPI1CON1bits.PPRE=0b11)
// ?	Set Secondary Pre-scalar for 1:1 ratio (SPI1CON1bits.SPRE=0b111)
// ?	Enable SDO output (SPI1CON1bits.DISSDO=0)
// ?	Enable SCK output (SPI1CON1bits.DISSCK=0)
         //SPI1CON1bits.MODE16=1;
         SPI1CON1bits.CKP=0; 		//sample on rising edge of SCK
	     SPI1CON1bits.CKE=1;        //
         SPI1CON1bits.MSTEN=1;
         SPI1CON1bits.SPRE=0b111;    //1:1 sec. prescale
	     SPI1CON1bits.PPRE=0b10;     //prim. prescale 4:1
        // SPI1CON1bits.PPRE=0b01;     //prim. prescale 16:1
         SPI1CON1bits.DISSDO=0;
	     SPI1CON1bits.DISSCK = 0;
        // SPI1CON2bits.FRMPOL = 1;//polarity high
        // SPI1CON2bits.FRMDLY = 0;//precedes
 //        SPI1CON2bits.FRMEN = 1; //frame enabled //!t
         // ?	Enable SPI module (SPI1STATbits.SPIEN=?)
         SPI1STATbits.SISEL=5;      //interrupt after transmitting
         SPI1STATbits.SPIEN=1;
 	   //  _SPI1IE  = 1;			//t Enable SPI1 interrupt
   }


inline void initSPI(void)
{
  //  RPINR22bits.SDI2R= 41;
  //  RPOR5bits.RP54R = 0b001000;//SDO2
  //  RPOR5bits.RP55R = 0b001001;//SCLK2
    TRISBbits.TRISB7=0; //LATCH output
    TRISBbits.TRISB8=0; //CLR output
    CLR= 0;
    cfgSpi1Master();   
}

unsigned int DAC(unsigned char adreg,unsigned int datreg)
{   
    _SPI1IF=0;
    SPI1BUF= adreg;
    Sel.W= datreg;
    while(!_SPI1IF);
    _SPI1IF=0;
    adpre= SPI1BUF;
    SPI1BUF=Sel.H;
    LATCH=0;
    while(!_SPI1IF);
    _SPI1IF=0;
    Sel.H= SPI1BUF;
    SPI1BUF=Sel.L;
    while(!_SPI1IF);
    _SPI1IF=0;
    Sel.L = SPI1BUF;
    LATCH=1; 
    if(adreg==READ)
    {
       SPI1BUF= 0;
       Sel.W= NOP;
       while(!_SPI1IF);
       _SPI1IF=0;
       adpre= SPI1BUF;
       SPI1BUF=Sel.H;
       LATCH=0;
       while(!_SPI1IF);
       _SPI1IF=0;
       Sel.H= SPI1BUF;
       SPI1BUF=Sel.L;
       while(!_SPI1IF);
       _SPI1IF=0;
       Sel.L = SPI1BUF;
       LATCH=1;  
    }
    return Sel.W;
}
//
void initDAC(unsigned int contr,unsigned int config)
{
    initSPI();
  //  Control.RANGE= 0b101;           //4...20mA
    Control.RANGE= 1;           //0...10V
    Control.OUTEN= 1;
    *help=DAC(CONTROL,contr);
    Flags.SOK =1;
} 
/*
//control transfers with DA,if ready, data from DA are saved at pread address 
int regDAC(int *pread)      //
{   int ret=0;
    if(Flags.SOK)           //if command already has transfered by SPI  
    {     
        LED101=1;//t
     *pread= Readat.W;      //read by SPI
     if(Flags.POST)
     {
          Flags.POST=0;     
          ret=datmem+0x80;           //if word read from SPI
     }
     else
     if(Flags.PRE)          //if new word is prepared its transfer requested
     {
      LATCH=0;   //t
      if(!Flags.FRD)        //if command is not "READ"
        Flags.PRE=0;         //preparing allowed
      Flags.SOK=0;          //command will be written
      LED101=0;//t
    //  LATCH=1;   
      if(Flags.FRD)         //if first READ instr. completed
      {
        Flags.FRD=0;                
        Flags.POST=1;       //flag for reading
        Sel.W= 0;           //follow 0 data 
        SPI1BUF= NOP;       //second NOP instruction
      }
      else
      {          
       if(adpre==READ)      //if READ command
       {
          datmem= datpre;          
          Flags.FRD=1;      // second instr. will follow  
       }   
       ret=1;
       Sel.W= datpre;
       SPI1BUF= adpre;
       adpre=NOP;
      }
    }    
   }
   return ret;
}

//prefer higher address of DA, then prepare address of register and its data 
//to addpre and datpre,set bit Flags.PRE and return 1  
int prepare(unsigned char adreg, int datreg)
{
  int prep=0;
  if(adreg >= adpre)
  {
      adpre= adreg;
      datpre= datreg;
      Flags.PRE=1;
      prep=1;
  }
  return prep;
}

void __attribute__((interrupt, no_auto_psv)) _SPI1Interrupt(void)
{      
       _SPI1IF=0;
       if(nsb==0)
       {
         // LATCH=0;      
           inb= SPI1BUF;
           SPI1BUF=Sel.H;
           nsb=1;        
       }
       else if(nsb==1)
       {
           Readat.H=SPI1BUF;
           SPI1BUF=Sel.L;
           nsb=2;       
       }
       else if(nsb==2)
       {
           Readat.L=SPI1BUF;
           nsb=0;
           Flags.SOK= 1;
           LATCH=1;         //t
       }
}
 */
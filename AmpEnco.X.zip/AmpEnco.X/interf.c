
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <libq.h>
#include "uart1Drv.h"
#include "uart2Drv.h"
#include "user.h"



dhl steps;
char al,la;

void interf(void)
{
        if(UF.Rec)        //USB->UART1 data from computer has been received
        {
            UF.Rec=0;
            UF.Edc=1;
            al= bufin[0];//t
            switch(al)
            {
                case 'o':               // position command received
                    //if(cwbuf[1] >= '0')
                    // n=atoi(&cwbuf[1]);//t
                    //else
                    {
                     bufout[0]='O';
                     steps.H=POS1CNTH;
                     steps.L=POS1CNTL;
                     sprintf(&bufout[1],"%ld",steps.D);
                     UF.Creq=1;
                    }
                    break;
                
                  
                default:
                {
                    if((al >= 'a')&&(al <= 'z'))
                     nilo=ni1;
                     memcpy(buflo,bufin,nilo); 
                     UF.Loreq=1;   
                }                
            }  
            UF.Edc=0;
         }
         if(UF.Relo)
         {
          UF.Relo=0;
          la=bufm2[0];
          if(isupper(la))
          {
              UF.Hireq=1;    
          }
          else
          if(islower(la))
          {
            switch(la)
            {
                LED101=1;//t
                case 'o':               // position command received
                    //if(cwbuf[1] >= '0')
                    // n=atoi(&cwbuf[1]);//t
                    //else
                    {
                     buflo[0]='O';
                     steps.H=POS1CNTH;
                     steps.L=POS1CNTL;
                     sprintf(&buflo[1],"%ld",steps.D);
                     UF.Loreq=1;
                    }
                    break;
                 default:
                {                    
                }                
            }              
          }
         }
         startU1tr();   //start transmit of this card data to UART1->USB 
         startU21tr();  //start  transmit of UART2->RS485 received data to UART1->USB
         startU2tr();   //start transmit of UART1->USB data for other card to UART2->RS485
}

#include <xc.h>
#include "feprom.h"



    _prog_addressT p,q,op; 
 int __attribute__((space(prog), aligned(_FLASH_PAGE*2))) dat[_FLASH_PAGE]= {3,500, 0x01001,0, 0,0, 0x12,0, 0,1000,2000,0x4000,4000,0x8000,7000,0xc000,11000,0xffff,15000,0xc000,18000,0x8000,20000,0x4000,21000,0};

int ie;


void InitFEPROM(long int *da,long int *ta)  //Init FEPROM
{
    int i;
    _init_prog_address(p,dat);   //t
    q=p;
    q= _memcpy_p2d24(&da[0],q,3);
       if(da[0]&0x800000) da[0]=da[0] | 0xff000000;
       q= _memcpy_p2d24(&ta[0],q,3);
       if(ta[0]&0x800000) ta[0]=ta[0] | 0xff000000;
   for(i=1;i< (FLASHPOLY + da[0]);i++)
    {
       q= _memcpy_p2d24(&da[i],q,3);
       if(da[i]&0x800000) da[i]=da[i] | 0xff000000;
       q= _memcpy_p2d24(&ta[i],q,3);
       if(ta[i]&0x800000) ta[i]=ta[i] | 0xff000000;
    }
}



void WriteFEPROM(long int *da,long int *ta)
{
    int i;
    _erase_flash(p);
    q=p;
    for(i=0; i <(FLASHPOLY + da[0]); i++)
    {         
     _write_flash_word48(q, da[i], ta[i]);
     q +=4;
    } 
}

 
#ifndef ANALOG_H
#define	ANALOG_H

#include <xc.h> // include processor files - each processor file is guarded.  


#endif	/* ANALOG_H */

extern void initComp(void);
extern void initAdc1(void);

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Threading;
using System.Globalization;

namespace EDA
{


    /// <summary>
    /// Interakční logika pro ADS.xaml
    /// </summary>
    struct AD
    {
        public static int T1,T2,T3,T4,Tin;
    }


    public partial class ADS : Window
    {
        string[] gains= {"1","2","4","8","16","32","64","128" };
        string[] sps = { "5", "10", "20", "50", "100", "200", "500", "1000" };
        string strm, stra;
        DispatcherTimer dispatcherTimerA = new DispatcherTimer();
        static int[] sy = { 9, 3, 4 };
        bitField sys0 = new bitField(sy);
        decimal Temp1, Temp2, Temp3, Temp4,TempIn;
        decimal Temp1R, Temp2R, Temp3R, Temp4R;
        bool GAINP=false, SAMP=false;
        public ADS()
        {
            InitializeComponent();
            Thread.CurrentThread.CurrentCulture = CultureInfo.CreateSpecificCulture("en-GB");
            iniTimerA();
            foreach (string gain in gains)
            {
                comboGain.Items.Add(gain);
            }
            comboGain.SelectedIndex = 4;//t
                                       //  comboBox.SelectedItem = "1";
            foreach (string samp in sps)
            {
                ComboSamples.Items.Add(samp);
            }
            ComboSamples.SelectedIndex = 2;//t
        }
        private void iniTimerA()
        {
            dispatcherTimerA.Tick += new EventHandler(dispatcherTimerA_Tick);
            dispatcherTimerA.Interval = new TimeSpan(0, 0, 0, 0, 200);
            dispatcherTimerA.Start();
        }

        private void checkBox_Click(object sender, RoutedEventArgs e)
        {
            if (checkBox.IsChecked==true)
                ser.serialWrite("k1");
            else ser.serialWrite("k0");
        }

   
        private void T1_MouseDown(object sender, MouseButtonEventArgs e)
        {
            ser.serialWrite("g");
        }

        private void T2_MouseDown(object sender, MouseButtonEventArgs e)
        {
            ser.serialWrite("h");
        }

        private void T3_MouseDown(object sender, MouseButtonEventArgs e)
        {
            ser.serialWrite("i");
        }

        private void T4_MouseDown(object sender, MouseButtonEventArgs e)
        {
            ser.serialWrite("j");
        }
       

        private void label_MouseDown(object sender, MouseButtonEventArgs e)
        {
            ser.serialWrite("t");
        }

        

        private void comboSamples_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (SAMP)
            {
                sys0.A[2] = (ushort)ComboSamples.SelectedIndex;
                sys0.A[1] = (ushort)comboGain.SelectedIndex;
                ushort SYS0 = sys0.AtoW();
                string cs = Convert.ToString(SYS0, 0x10);
                ser.serialWrite("s" + cs);
            }
            else SAMP = true;
        }

        private void comboGain_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (GAINP)
            {
                sys0.A[2] = (ushort)ComboSamples.SelectedIndex;
                sys0.A[1] = (ushort)comboGain.SelectedIndex;
                ushort SYS0 = sys0.AtoW();
                string cs = Convert.ToString(SYS0, 0x10);
                ser.serialWrite("s" + cs);
            }
            else GAINP = true;
        }

        private void textBlock_MouseEnter(object sender, MouseEventArgs e)
        {
            ser.serialWrite("q");
        }

        private void dispatcherTimerA_Tick(object sender, EventArgs et)
        {
            //int state;
            try
            {
                if (ser.serial.IsOpen && (ser.inserad.Count > 0))
                {
                    strm = ser.inserad.Dequeue();
                    if (strm != "")
                    {
                        stra = strm.Remove(1);
                        strm = strm.Remove(0, 1);
                        switch (stra)
                        {
                            case "G":
                                Temp1 = Decimal.Parse(strm);                               
                                //T1.Content = "T1=" + strm + "°C";   
                                if(Temp1 > 2000)
                                    T1.Content = "T1 NOT CONNECTED";
                                else
                                    T1.Content = "T1=" + Temp1.ToString("0.00") + "°C";
                                break;
                            case "H":
                                Temp2 = Decimal.Parse(strm);
                                if (Temp2 > 2000)
                                    T2.Content = "T2  NOT CONNECTED";
                                else 
                                    T2.Content = "T2=" + Temp2.ToString("0.00") + "°C";
                                break;
                            case "I":
                                Temp3 = Decimal.Parse(strm);
                                if (Temp3 > 2000)
                                    T3.Content = "T3  NOT CONNECTED";
                                else
                                    T3.Content = "T3=" + Temp3.ToString("0.00") + "°C";
                                break;
                            case "J":
                                Temp4 = Decimal.Parse(strm);
                                if (Temp4 > 2000)
                                    T4.Content = "T4  NOT CONNECTED";
                                else
                                    T4.Content = "T4=" + Temp4.ToString("0.00") + "°C";
                                break;
                            case "T":
                                TempIn = Decimal.Parse(strm);
                                Tin.Content = "Tcold=" + TempIn.ToString("0.00") + "°C";                               
                                break;
                            case "Q":
                                textBlock.Text = strm;
                                break;


                            default: break;
                        }

                    }
                }
                

            }
            catch (Exception e)
            {
                System.Windows.MessageBox.Show(e.ToString());

            }

        }
       
    }
}

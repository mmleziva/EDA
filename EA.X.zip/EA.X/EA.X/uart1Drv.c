#include "user.h"
#include <string.h>
#include "uart1Drv.h"
#include "SPI.h"
volatile signed int bcin,ni,ni1,ni21, no, nilo,Nstr,bcerr;
char bufout[BUFSUPR+1],bufotr[BUFSUPR+1],bufire[BUFMAX+1],bufin[BUFSUPR+1],bufm2[BUFMAX+1];
char   *pbufout,*pbufotr,*pbufin,*pbufico, *pbufm2, *pbufire, *pbuflo,*pbuflim;
uf UF;
//unsigned int lena;
uint16_t axbuf;

void iniDMA(void)
{
    DMA0CONbits.DIR=1;
    DMA0CONbits.SIZE=1;
    DMA0CONbits.MODE=1;
    DMA0STAL = __builtin_dmaoffset(bufotr);
    DMA0STAH= 0x00;
    DMA0PAD = (volatile unsigned int) &U1TXREG;
    DMA0REQbits.IRQSEL= 0x0c;
 // Clearing Channel 0 Interrupt Flag;
    IFS0bits.DMA0IF = 0;
    // Enabling Channel 0 Interrupt
    IEC0bits.DMA0IE = 1;
}

void __attribute__ ( ( interrupt, no_auto_psv ) ) _DMA0Interrupt( void )
{
	no=0;             //transmit finished
    pbufotr=&bufotr[0];
    UF.Ctra=0;
	
    IFS0bits.DMA0IF = 0;
}
// UART Configuration
void cfgUart1(void)
{   
    RPINR18bits.U1RXR = 54; // U1RX on RP54
    RPOR5bits.RP55R = 0x01; // U1TX on RP55
    pbufire=&bufire[0];
    pbufico=bufin;
    pbufin=bufin;
    pbufotr=&bufotr[0];
    bufire[BUFMAX]=0;
    bufout[BUFMAX]=0;
	U1MODEbits.STSEL = 0;			// 1-stop bit
	U1MODEbits.PDSEL = 0;			// No Parity, 8-data bits
	U1MODEbits.ABAUD = 0;			// Autobaud Disabled
    U1MODEbits.BRGH =  1;
	U1BRG = BRGVAL;					// BAUD Rate Setting for 115200


	//********************************************************************************
	//  STEP 1:
	//  Configure UART for DMA transfers
	//********************************************************************************/
	U1STAbits.UTXISEL0 = 0;		// interrupt after transfer completing
	U1STAbits.UTXISEL1 = 1;		//!t    interrupt after transfer to TSR              
	U1STAbits.URXISEL  = 0;			// Interrupt after one RX character is received

	//********************************************************************************
	//  STEP 2:
	//  Enable UART Rx and Tx
	//********************************************************************************/
	U1MODEbits.UARTEN   = 1;		// Enable UART
	U1STAbits.UTXEN     = 1;		// Enable UART Tx
    IEC4bits.U1EIE = 1;             //enable error com interrupt
    _U1RXIE=1;				//enable receiver interrupt
 //   _U1TXIE=1;
    _U1TXIF=0;
    _U1RXIF=0;
    iniDMA();
}

void startU1tr(unsigned int len)//start transmit of this card data to UART1->USB 
{
    if((len>0) && (len < BUFSUPR)&& !UF.Ctra)
 //   if(!UF.Ctra)
    {
        //    lena=len;
            UF.Ctra=1;
            memcpy(bufotr,bufout,len);
            pbufotr= &bufotr[0];
          //  U1TXREG=*pbufotr; 
            DMA0CNT= len;
            DMA0CONbits.CHEN=1;
            DMA0REQbits.FORCE = 1;
    }
}

void startU21tr(void)//start  transmit of UART2->RS485 received data to UART1->USB
{
    if(UF.Hireq &&!UF.Creq && !UF.Ctra)
    {
           UF.Hireq=0;  //null request of this start function
           UF.Ctra=1;   //setflag of transmitting
           UF.Edlo = 1;          
            memcpy(bufotr,bufm2,ni21);
            pbufotr= &bufotr[0];
            U1TXREG=*pbufotr; 
            UF.Edlo = 0;
    }
}

//receive data ISR
void __attribute__((interrupt, no_auto_psv)) _U1RXInterrupt (void)
{
 if(U1STAbits.OERR)U1STAbits.OERR=0;		// Enable UART Tx
 bcin=(char)U1RXREG;
 _U1RXIF=0;
 if(((bcin==' ')||(bcin=='\n')))
     *pbufire=0;
 else *pbufire=bcin;
 if((ni>=(BUFMAX-1))||(*pbufire==0))
 {                      //value received
  if(!UF.Edc)
  {
  //  pbufire=&bufire[0];
       
    if(UF.Rec)
    {
        UF.Rec=0;
        pbufico= bufin;
        pbufin= bufin;
    }
    Nstr++;
    ni++;           //number of chars received
    memcpy(pbufin,bufire,ni);
    pbufire = bufire;
    ni1=ni;
    ni=0;
    pbufin += ni;
	
 
   } 
 }
 else
 {              //receiving continue
  pbufire++;
  ni++;
 } 
 return;
}

/*
void __attribute__((interrupt, no_auto_psv)) _U1TXInterrupt (void)
{
   _U1TXIF=0;
    if((no < lena))
   {
    no++;                   //transmit continue
    pbufotr++;
    U1TXREG=*pbufotr;
   } 
   else {
          no=0;             //transmit finished
          pbufotr=&bufotr[0];
          UF.Ctra=0;
        }     
}
*/

void __attribute__ ((interrupt, no_auto_psv)) _U1ErrInterrupt(void)
{  
  if(U1STAbits.OERR)
  {
     U1STAbits.OERR  = 0; 
  }
    	IFS4bits.U1EIF = 0; // Clear the UART1 Error Interrupt Flag 
              
}

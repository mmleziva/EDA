
unsigned long int umuelu(unsigned int vel,unsigned int prop);
                    // f=  vel * prop; uint vel, prop, ulong f

unsigned long int lumfelu(unsigned long int vel,unsigned int fract);
                    // f=  vel * fract; ulong vel, uint fract, ulong f

unsigned  int ludueu(unsigned long int dividend, unsigned int divider);
                    // f=  dividend / divider; ulong dividend, uint divider, f

unsigned  long int udueuf(unsigned int dividend, unsigned int divider);
                    // f=  dividend / divider; uint dividend, uint divider, ulong(uint,fract) f
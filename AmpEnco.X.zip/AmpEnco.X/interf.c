
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <libq.h>
#include "uart1Drv.h"
#include "uart2Drv.h"
#include "user.h"
#include "SPI.h"
#include "interf.h"



dhl steps;
char al,la;
int n,m,kn;
unsigned int NP;
long int  inkrpar[FLASHI];
long int  voltrpar[FLASHI];
unsigned int  *const pencod= (unsigned int *) &inkrpar[3];
unsigned int  *const dacontrol= (unsigned int *) &inkrpar[1];
unsigned int  *const daconfig= (unsigned int *)&voltrpar[1];
long int * const inkr=(long int *)&inkrpar[FLASHPOLY];
long int * const voltr=(long int *)&voltrpar[FLASHPOLY];//t
unsigned int ax;
unsigned int dao,dacont, readreg, rat;
unsigned int lenght;
void interf(void)
{
         while(Nstr>0)  //USB->UART1 data from computer has been received
         {
            Nstr--;
            al= *pbufico;//t
            pbuflim= bufout+ BUFMAX-12; 
            switch(al)
            {
                case 'o':               // position command received
                    if(pbufico[1] >= '0')
                    {                      
                    }
                    else
                    {
                     steps.H=POS1CNTH;
                     steps.L=POS1CNTL;
                     lenght = sprintf(bufout,"O%ld",steps.D)+1;
                    }
                    break;
                case 'e':               // position command received
                    if(pbufico[1] >= '0')
                    {       
                     *pencod = strtol(&pbufico[1],&pbufico,10);//t
                     pbufico++;    
                     if((*pencod & 0x0010)!= 0)
                     {
                         CM1CONbits.CREF=1;  
                         CM2CONbits.CREF=1;
                         CM3CONbits.CREF=1;
                         CM4CONbits.CREF=1;
                     }
                     else
                     {
                         CM1CONbits.CREF=0;  
                         CM2CONbits.CREF=0;
                         CM3CONbits.CREF=0;
                         CM4CONbits.CREF=0;
                     }
                     CVRCONbits.CVR= *pencod & 0x000f;
                     bufout[0]='E';// position command received  
                     bufout[1]=0;
                     lenght=2;
                    }
                    else
                    {
                     lenght = sprintf(bufout,"E%u",*pencod)+1;
                    }
                    break;
                case 'v':                   // voltage command received
                    if(pbufico[1] >= '0')
                    {
                     voltr[m]=strtol(&pbufico[1],&pbufico,10);//t
                     pbufico++;
                     m++;
                    } 
                    else
                    {
                     }
                    break;
                case 'p':                 // position command received
                    if(pbufico[1] >=  '0')
                    {
                     inkr[m]=strtol(&pbufico[1],&pbufico,10);//t
                     pbufico++;
                    }
                    else
                    {
                      pbufout=bufout;
                      for(n=0;n<NP;n++)
                      {
                        ax=(unsigned int)inkr[n];
                        kn= sprintf(pbufout,"P%u",ax);
                        pbufout += kn;
                        pbufout++;    
                        ax=(unsigned int)voltr[n];
                        kn= sprintf(pbufout,"V%u",ax);
                        pbufout += kn;
                        pbufout++;  
                        if(pbufout >= pbuflim)
                            break;
                      }
                      *pbufout='P';
                      pbufout++;
                      *pbufout=0;
                      pbufout++;
                      lenght = pbufout-bufout;
                    }
                    break;
                case 's':       
                    bufout[0]='S';// position command received  
                    bufout[1]=0;
                    NP=m;
                    m=0;
                    lenght=2;
                    pbufico+= 2;
                    UF.Creq= 1;
                    break;   
                case 'f':                    // config. command received
                   if(pbufico[1] >=  '0')
                    {
                     dacont= strtol(&pbufico[1],&pbufico,10);//t
                     pbufico++;    
                     *daconfig=  dacont;
                     DAC(CONFIG ,dacont);
                    }
                    else
                    {                                       
                //     DAC(READ,READCONFIG);//command for read control register 
                       pbufout=bufout;
                       ax=*daconfig;
                       kn= sprintf(pbufout,"F%u",ax);
                       pbufout += kn;
                       pbufout++;   
                       lenght = pbufout-bufout;
                    }
                    break; 
                case 'c':                    // control command received
                    if(pbufico[1] >=  '0')
                    {
                     dacont= strtol(&pbufico[1],&pbufico,10);//t
                     pbufico++;  
                     *dacontrol=  dacont;
                     DAC(CONTROL ,dacont);
                     bufout[0]='C';// position command received  
                     bufout[1]=0;
                     lenght=2;
                     break;   
                    }
                    else
                    {   
                        pbufout=bufout;
                        ax=*daconfig;
                        kn= sprintf(pbufout,"F%u",ax);
                        pbufout += kn;
                        pbufout++;  
                        ax=*dacontrol;
                        kn= sprintf(pbufout,"C%u",ax);
                        pbufout += kn;
                        pbufout++;    
                        lenght = pbufout-bufout;
                    // DAC(READ,READCONTROL);//command for read control register 
                    }
                    break; 
                default:
                {
                    if((al >= 'a')&&(al <= 'z'))
                     nilo=ni1;
                     memcpy(buflo,bufin,nilo); 
                     UF.Loreq=1;   
                }                
            }  
       //     pbufico+= lenght;
            UF.Edc=0;
            if(Nstr==0)
               UF.Rec= 1;
         }
         
         if(UF.Relo)
         {
          UF.Relo=0;
          la=bufm2[0];
          if(isupper(la))
          {
              UF.Hireq=1;    
          }
          else
          if(islower(la))
          {
            switch(la)
            {
                LED101=1;//t
                case 'o':               // position command received
                    //if(cwbuf[1] >= '0')
                    // n=atoi(&cwbuf[1]);//t
                    //else
                    {
                     buflo[0]='O';
                     steps.H=POS1CNTH;
                     steps.L=POS1CNTL;
                     sprintf(&buflo[1],"%ld",steps.D);
                     UF.Loreq=1;
                    }
                    break;
                 default:
                {                    
                }                
            }              
          }
  
         }
  //       if(lenght>0)
  //       {
            startU1tr(lenght);   //start transmit of this card data to UART1->USB 
            lenght=0;
   //      }

    //     startU21tr();  //start  transmit of UART2->RS485 received data to UART1->USB
    //     startU2tr();   //start transmit of UART1->USB data for other card to UART2->RS485
}

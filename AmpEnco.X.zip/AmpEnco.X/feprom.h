
#ifndef FEPROM_H
#define	FEPROM_H
#include "libpic30.h"

void InitFEPROM(long int *da,long int *ta);  //Init FEPROM
void WriteFEPROM(long int *da,long int *ta);  //Init FEPROM

#endif	/* FEPROM_H */

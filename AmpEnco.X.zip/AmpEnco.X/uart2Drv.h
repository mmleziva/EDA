
// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef UART2DRV_H
#define	UART2DRV_H

#include <xc.h> // include processor files - each processor file is guarded. 
extern void startU2tr(void);
extern void cfgUart2(void);
#endif	/* UART2DRV_H */


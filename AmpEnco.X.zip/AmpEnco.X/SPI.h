#ifndef SPI_H
#define SPI_H

#define LATCH _RB7
#define CLR   _RB8

#define NOP      0x00
#define DATA     0x01
#define READ     0x02
#define CONTROL  0x55
#define RESET    0x56
#define CONFIG   0x57
#define GAIN     0x58
#define ZERO     0x59
#define WATCHD   0x95

#define READSTATUS  0b0
#define READDATA    0b01
#define READCONTROL 0b010
#define READCONFIG  0b001011
#define READGAIN    0b010011
#define READZERO    0b010111

typedef union
{
 struct
 {
    unsigned RANGE: 3;
    unsigned DCEN:  1;
    unsigned SREN:  1;  
    unsigned SRSTEP:3; 
    unsigned SRCLK: 4; 
    unsigned OUTEN: 1;  
    unsigned REXT:  1;
    unsigned OVR:   1;  
    unsigned CLRSEL:1;  
 };
 struct
 {
    unsigned char L;
    unsigned char H; 
 };
 unsigned int W; 
}contr;

typedef union
{
 struct
 {
    unsigned WDPD: 2;
    unsigned WDEN:  1;
    unsigned SREN:  1;  
    unsigned CRCEN: 1; 
    unsigned HARTEN:1; 
    unsigned CALEN: 1;  
    unsigned:  1;
    unsigned APD:   1;  
    unsigned DUAL_OUTEN:1; 
    unsigned IOUT_RANGE:1;    
 };
 struct
 {
    unsigned char L;
    unsigned char H; 
 };
 unsigned int W; 
} config;

typedef union
{
 struct
 {
    unsigned T_FLT: 1;
    unsigned SR_ON:  1;
    unsigned I_FLT:  1;  
    unsigned WD_FLT:1; 
    unsigned CRC_FLT:1;  
 };
 struct
 {
    unsigned char L;
    unsigned char H; 
 };
 unsigned int W; 
}status;

 void initSPI(void);
 void initDAC(void);
 int regDAC(int *pread);
 int prepare(unsigned char adreg, int datreg);
 
#endif
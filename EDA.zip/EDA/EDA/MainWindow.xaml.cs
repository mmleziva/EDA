﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
//using System.Windows.Forms;

namespace EDA
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>

    public class MyObint
    {
        int p;
        int v;
        decimal m;
        decimal a;
        public int PositionBits
        {
            get { return p; }
            set { p = value; }
        }

        public int OutBits
        {
            get { return v; }
            set { v = value; }
        }

        public decimal PositionMeter
        {
            get { return m; }
            set { m = value; }
        }

        public decimal OutVoltmAmp
        {
            get { return a; }
            set { a = value; }
        }

        // public MyObint(int pi, int vi)
        public  MyObint(int pi, int vi)
        {
            p = pi;
            v = vi;
        }

        public MyObint(decimal mi, decimal ai)
        {
            m = mi;
            a = ai;
        }
        public MyObint()
        {

        }
    }

    struct b
    {
        
    }

    public partial class MainWindow : Window
    {

        List<MyObint> ocici;
        List<bitField> AR;
        UInt16[] reg;
        int[][] shift;            
        string strm, stra, str;
        bool  REF = false;        
        int sel,selam, row, down=0;
        int ratio = 500;
        int N = 0;
        int NMAX = 9;
        int ico = 0;
        char[] alphas = { 'A', 'B', 'C', 'D', 'G', 'M', 'N', 'P', 'R', 'V','S' };
        char[] cutchar = { '\0', '\n', ';', ',' };
        
        DispatcherTimer dispatcherTimer = new DispatcherTimer();
        const int MAXC = 20;
        StringBuilder sa;
        bool  OUC = false;
        string[] ost = { "0 ..+5V", "0 ..+10V", "-5..+5V(Positive only)", "-10..+10V(Positive only)", "Not allowed", "4 ..20mA", "0 ..20mA", "0 ..24mA" };
        string[] mamp = { "Not allowed", "4 ..20mA", "0 ..20mA", "0 ..24mA" };
        string[] stepsize = { " 1 ", " 2 ", " 4 ", " 8  ", " 16 ", " 32 ", " 64 ", " 128 " };
        string[] updateclock = { " 258065 ", " 200000 ", " 153845 ", "131145  ", " 115940 ", " 69565 ", " 37560 ", " 25805 ", "20150", "16030", "10 295", "8280", "6900", "5530", "4240", "3300" };
        string postr, vostr;
        public MainWindow()
        {
            InitializeComponent();
            ocici = new List<MyObint>();
            ocici.Add(new MyObint());
            this.dataGrid.ItemsSource = ocici;            
            iniSerial();
            //ser.BOPEN = true;
            iniTimer();
           // ser.serialWrite("a");//t
        }

        private void iniSerial()
        {
            ser.Iniser();
            comboBox.ItemsSource = ser.ports;
            comboBox.SelectedIndex = ser.n;
            if (ser.serial.IsOpen)
            {
                comboBox.Background = Brushes.Green;
                comboBox.Foreground = Brushes.DarkGreen;
            }
      
            sa = new StringBuilder();//t
            ser.BOPEN = true;
        }

        private void iniTimer()
        {
            dispatcherTimer.Tick += new EventHandler(dispatcherTimer_Tick);
            dispatcherTimer.Interval = new TimeSpan(0, 0, 0, 0, 100);
            dispatcherTimer.Start();
        }

        private void dispatcherTimer_Tick(object sender, EventArgs et)
        {
            //int state;
            try
            {
                // if (ser.serial.IsOpen && (ser.inser.Count > 0))
                while (ser.serial.IsOpen && (ser.inser.Count > 0))
                {

                    strm = ser.inser.Dequeue();
                    //   stra = strm.Remove(1);
                    //   if (strm != "")
                    if (strm.Length > 1)
                    {
                        stra = strm.Remove(1);//t
                        strm = strm.Remove(0, 1);
                        switch (stra)
                        {

                            case "C":
                                OUC = true;
                                reg[0] = UInt16.Parse(strm);
                                label.Content = strm;
                                AR[0].WtoA(reg[0]);

                                if (AR[0].A[3] == 0) outEn.IsChecked = false;
                                else outEn.IsChecked = true;
                                comboBox1.SelectedIndex = AR[0].A[8];
                                break;
                            case "R":                       //t
                                label.Content = "R" + strm;
                                pulm.Text = strm;
                                ratio = int.Parse(strm);
                                ser.serialWrite("p");
                                break;
                            case "M":
                                N = 0;
                                ser.serialWrite("n" + N.ToString());
                                NMAX = int.Parse(strm);
                                ser.serialWrite("r");
                                break;
                            case "P":
                                //    while (ocici.Count <= N)
                                ocici.Add(new MyObint());
                                ocici[N].PositionBits = int.Parse(strm);
                                ocici[N].PositionMeter = btoP(ocici[N].PositionBits);
                                //   ser.serialWrite("v");
                                break;
                            case "V":
                                ocici[N].OutBits = int.Parse(strm);
                                ocici[N].OutVoltmAmp = btoV(ocici[N].OutBits);
                                if (N < (NMAX - 1))//t
                                {
                                    N++;
                                    //                       ser.serialWrite("n" + N.ToString());
                                    //                      ser.serialWrite("p");
                                }
                                else
                                {
                                    dataGrid.Items.Refresh();
                                    ser.serialWrite("c");           //t
                                }
                                break;
                            case "A":
                                ushort na = ushort.Parse(strm);
                                AR[2].WtoA(na);
                                if (na == 0)
                                {
                                    alarm.Content = "DA converter OK";
                                    alarm.Background = Brushes.LightBlue;
                                }
                                else
                                {
                                    alarm.Background = Brushes.LightPink;
                                    if (AR[2].A[1] != 0) alarm.Content = "CRC error on SPI";
                                    if (AR[2].A[2] != 0) alarm.Content = "Watchdog timer timeout";
                                    if (AR[2].A[3] != 0) alarm.Content = "Current loop open ";
                                    if (AR[2].A[4] != 0) alarm.Content = "DAC code sleeving";
                                    if (AR[2].A[5] != 0) alarm.Content = "Overtemperature";

                                }
                                break;
                            case "O":
                                testext.Text = strm;
                                break;
                            default:
                                break;
                        }

                    }
                    else
                    { 
                        switch (strm)//t
                        {
                            /*
                            case "P":
                                if (ico < ocici.Count)
                                {
                                    vostr = ocici[ico].OutBits.ToString();
                                    ser.serialWrite("v" + vostr);
                                }
                                else
                                {
                                    ser.serialWrite("s");
                                    ico = 0;
                                }
                                break;
                            case "V":
                               
                                if (ico < ocici.Count)
                                {
                                    postr = ocici[ico].PositionBits.ToString();
                                    ico++;
                                    if (ico < ocici.Count)
                                        ser.serialWrite("p" + postr);
                                    else
                                    {
                                        ser.serialWrite("s");
                                        ico = 0;
                                    }

                                }
                                
                                break;
                            */
                            case "S":
                                dataGrid.Items.Refresh();
                                break;
                            default:
                                break;

                        }
                    }
                }
            //    else
                if (REF)
                {
                    REF = false;
                    down = 2;
                    recount();
          //          dataGrid.Items.Refresh();
                    
                }
                else if(down>0)
                {
                    down--;
                    if(down==0)
                        dataGrid.Items.Refresh();

                }
                
            }
            catch (Exception e)
            {
                System.Windows.MessageBox.Show(e.ToString());

            }

        }

        private void label_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            ser.serialWrite("c");

        }

        private void polySave_Click(object sender, RoutedEventArgs e)
        {
    //        string postr, vostr;
            try
            {
                dataGrid.Items.Refresh();
                if ((ocici[ocici.Count - 1].PositionBits == 0) && (ocici[ocici.Count - 1].OutBits == 0))
                    ocici.Remove(ocici[ocici.Count - 1]);
                ocici.Sort(delegate (MyObint x, MyObint y)
                             {
                                 return x.PositionBits.CompareTo(y.PositionBits);
                             }
                          );

                
                                for (int ico = 0; ico < ocici.Count; ico++)
                                {
                                    postr = ocici[ico].PositionBits.ToString();
                                    ser.serialWrite("p" + postr);
                                    vostr = ocici[ico].OutBits.ToString();
                                    ser.serialWrite("v" + vostr);
                                }
                                ser.serialWrite("s");
              
                ico = 0;//t
        //        postr = ocici[ico].PositionBits.ToString();
        //        ser.serialWrite("p" + postr);
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.ToString());
            }
        }

        private void polyLoad_Click(object sender, RoutedEventArgs e)
        {
            //   ser.serialWrite("m");
            ser.serialWrite("p");
            ocici.Clear();//t
            N = 0;
        }

        private void outEn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (outEn.IsChecked == true) AR[0].A[3] = 1;
                else AR[0].A[3] = 0;
                reg[0] = AR[0].AtoW();
                ser.serialWrite("c" + reg[0].ToString());
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.ToString());
            }

        }

        private void textBox_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            str = textBox.Text;
            ser.serialWrite(str);
        }

        private void testext_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            ser.serialWrite("o");
        }
     
        private void comboBox_ContextMenuOpening(object sender, ContextMenuEventArgs e)
        {
            try
            {
                comboBox.SelectedIndex = 0;
                ser.Getportnames();
                foreach (string comport in ser.ports)
                {
                    comboBox.Items.Add(comport);
                }
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.ToString());
            }
        }

        private void Window_Initialized(object sender, EventArgs e)
        {
            try
            {
                foreach (string s in ost)
                {
                    comboBox1.Items.Add(s);
                }
                comboBox1.SelectedIndex = 1;
                sel = comboBox1.SelectedIndex;
                foreach (string s in mamp)
                {
                    comboBox11.Items.Add(s);
                }
                comboBox11.SelectedIndex = 1;
                selam = comboBox11.SelectedIndex;
                foreach (string s in stepsize)
                {
                    comboBox2.Items.Add(s);
                }
                comboBox2.SelectedIndex = 0;
                foreach (string s in updateclock)
                {
                    comboBox3.Items.Add(s);
                }
                comboBox3.SelectedIndex = 0;
                reg = new UInt16[0x3];
                reg[0] = 0;
                shift = new int[0x3][];
                shift[0x0] = new int[] { 1, 1, 1, 1, 4, 3, 1, 1, 3 };            //control
                shift[0x1] = new int[] { 5, 2, 1, 1, 1, 1, 1, 1, 1, 2 };        //configuration
                shift[0x2] = new int[] { 11, 1, 1, 1, 1, 1 };                    //status          
                AR = new List<bitField>();
                AR.Add(new bitField(shift[0]));
                AR.Add(new bitField(shift[1]));
                AR.Add(new bitField(shift[2]));
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.ToString());
            }
        }

        private void comboBox1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (ser.BOPEN)
                {
                    
                    string cs;
                    sel = comboBox1.SelectedIndex;
                    for (int N = 0; N < ocici.Count; N++)
                        ocici[N].OutVoltmAmp = btoV(ocici[N].OutBits);
                    AR[0].A[8] = (ushort)sel;
                    reg[0] = AR[0].AtoW();
                    if (OUC)
                        OUC = false;
                    else
                    ser.serialWrite("c" + reg[0].ToString());
                    switch (sel)
                    {
                        case 5:
                        case 6:
                        case 7:
                            cs = "Current";
                            break;
                        default:
                            cs = "Voltage";
                            break;
                    }
                    dataGrid.Columns[3].Header = cs;

                    dataGrid.Items.Refresh();
                }
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.ToString());
            }
        }  

        private void bout_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if ((bool)bout.IsChecked)
                    dataGrid.Columns[1].Visibility = Visibility.Visible;
                else dataGrid.Columns[1].Visibility = Visibility.Collapsed;
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.ToString());
            }
        }

        private void bpos_Click(object sender, RoutedEventArgs e)
        {
            if ((bool)bpos.IsChecked)
                dataGrid.Columns[0].Visibility = Visibility.Visible;
            else dataGrid.Columns[0].Visibility = Visibility.Collapsed;
        }

        private void outm_Click(object sender, RoutedEventArgs e)
        {
            if ((bool)outm.IsChecked)
                dataGrid.Columns[2].Visibility = Visibility.Visible;
            else dataGrid.Columns[2].Visibility = Visibility.Collapsed;
        }

        private void outvma_Click(object sender, RoutedEventArgs e)
        {
            if ((bool)outvma.IsChecked)
                dataGrid.Columns[3].Visibility = Visibility.Visible;
            else dataGrid.Columns[3].Visibility = Visibility.Collapsed;
        }

        private void incrout_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (incrout.IsChecked == true) AR[0].A[1] = 1;
                else AR[0].A[1] = 0;
                reg[0] = AR[0].AtoW();
                ser.serialWrite("c" + reg[0].ToString());
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.ToString());
            }
        }

        private void slewen_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (slewen.IsChecked == true)
                {
                    AR[0].A[6] = 1;
                    reg[0] = AR[0].AtoW();
                    ser.serialWrite("c" + reg[0].ToString());
                    comboBox2.IsEnabled = true;
                    // comboBox2.IsEditable = true;
                    comboBox3.IsEnabled = true;
                }
                else
                {
                    AR[0].A[6] = 0;
                    reg[0] = AR[0].AtoW();
                    ser.serialWrite("c" + reg[0].ToString());
                    comboBox2.IsEnabled = false;
                    //   comboBox2.IsEditable = false;
                    comboBox3.IsEnabled = false;
                }
                reg[0] = AR[0].AtoW();
                ser.serialWrite("c" + reg[0].ToString());
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.ToString());
            }
        }

        private void comboBox2_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (ser.BOPEN)
                {
                    sel = comboBox2.SelectedIndex;
                    AR[0].A[5] = (ushort)sel;
                    reg[0] = AR[0].AtoW();
                    ser.serialWrite("c" + reg[0].ToString());
                }
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.ToString());
            }
        }

        private void comboBox3_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (ser.BOPEN)
                {
                    sel = comboBox3.SelectedIndex;
                    AR[0].A[4] = (ushort)sel;
                    reg[0] = AR[0].AtoW();
                    ser.serialWrite("c" + reg[0].ToString());
                }


            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.ToString());
            }
        }

        private void recount()
        {
            try
            {
       //         int row = dataGrid.SelectedIndex;
                if ((row >= 0) && (row < ocici.Count)
                    && (dataGrid.CurrentCell.Column != null))
                {
                    int col = dataGrid.CurrentCell.Column.DisplayIndex;
                    switch (col)
                    {
                        case 0:
                            ocici[row].PositionMeter = btoP(ocici[row].PositionBits);
                            break;
                        case 1:
                            ocici[row].OutVoltmAmp = btoV(ocici[row].OutBits);
                            break;
                        case 2:
                            ocici[row].PositionBits = Ptob(ocici[row].PositionMeter);
                            break;
                        case 3:
                            ocici[row].OutBits = Vtob(ocici[row].OutVoltmAmp);
                            break;
                    }
               //     dataGrid.Items[row] = ocici[row];
                    // REF = true;
                }
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.ToString());
            }
        }

        private void DualOut_Click(object sender, RoutedEventArgs e)
        {
            if (DualOut.IsChecked == true) AR[1].A[2] = 1;
            else AR[1].A[2] = 0;
            reg[1] = AR[1].AtoW();
            ser.serialWrite("f" + reg[1].ToString());
        }

        private void comboBox11_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (ser.BOPEN)
                {

                    string cs;
                    selam = comboBox11.SelectedIndex;
                    for (int N = 0; N < ocici.Count; N++)
                        ocici[N].OutVoltmAmp = btoV(ocici[N].OutBits);
                    AR[1].A[1] = (ushort)selam;
                    reg[1] = AR[1].AtoW();
                    if (OUC)
                        OUC = false;
                    else
                        ser.serialWrite("f" + reg[1].ToString());
                    switch (sel)
                    {
                        case 5:
                        case 6:
                        case 7:
                            cs = "Current";
                            break;
                        default:
                            cs = "Voltage";
                            break;
                    }
                    dataGrid.Columns[3].Header = cs;

                    dataGrid.Items.Refresh();
                }
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.ToString());
            }
        }

        private void dataGrid_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
     //       if(e.Key== Key.Enter)
      //      {
       //         row = dataGrid.SelectedIndex;
        //        REF = true;
       //     }
        }

        private void dataGrid_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
        {
            if (Keyboard.IsKeyDown(Key.Enter))
            {
                row = dataGrid.SelectedIndex;
                REF = true;
                // recount();
                // down = 5;
            }
        }

        private void dataGrid_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
           // row = dataGrid.SelectedIndex;
            //  recount();
           //  REF = true;
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            if (ser.serial.IsOpen)
                ser.serial.Close();
        }

        private void refresh_Click(object sender, RoutedEventArgs e)
        {
            //  REF = true;
            dataGrid.Items.Refresh();
          //  dataGrid.Items[1] = ocici[1];
        }

        private void pulm_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            foreach (var v in ocici)
            {
                v.PositionMeter = btoP(v.PositionBits);
            }
            ratio = int.Parse(pulm.Text);
            ser.serialWrite("r" + pulm.Text);
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
         //   ADS ads = new ADS();
          //  ads.Show();
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
        //    ECmotors eCmotors = new ECmotors();
         //   eCmotors.Show();
        }

        private void comboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (ser.BOPEN)
                {
                    //ser.ports = SerialPort.GetPortNames();
                    ser.Getportnames();
                    comboBox.ItemsSource = ser.ports;
                    if (!ser.serial.IsOpen)
                    {
                        ser.serial.PortName = (string)comboBox.SelectedItem;
                        ser.serial.Open();
                        comboBox.Background = Brushes.Green;
                        comboBox.Foreground = Brushes.DarkGreen;
                    }
                    else
                    {
                        ser.serial.Close();
                        comboBox.Background = Brushes.Yellow;
                        comboBox.Foreground = Brushes.DarkRed;
                    }
                }
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.ToString());
            }
        }

       

        decimal btoV(int bits)
        {
            decimal o = 0;
            try
            {

                switch (sel)
                {
                    case 0:
                        o = (decimal)bits * 5 / 0x10000;
                        break;
                    case 1:
                        o = (decimal)bits * 10 / 0x10000;
                        break;
                    case 5:
                        o = 4 + (decimal)bits * 16 / 0x10000;
                        break;
                    case 6:
                        o = (decimal)bits * 20 / 0x10000;
                        break;
                    case 7:
                        o = (decimal)bits * 24 / 0x10000;
                        break;

                }
                o = Decimal.Round(o, 4);

            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.ToString());
            }
            return o;
        }

        decimal btoP(int bits)
        {
            decimal o = 0;
            try
            {
                o = (decimal)bits / (ratio * 4);
                o = Decimal.Round(o, 4);
            }
            catch (Exception e)
            {
                System.Windows.MessageBox.Show(e.ToString());
            }
            return o;
        }

        int Vtob(decimal volts)
        {
            int o = 0;
            decimal d = 0;
            try
            {
                switch (sel)
                {
                    case 0:
                        d = volts * 0x10000 / 5;
                        break;
                    case 1:
                        d = volts * 0x10000 / 10;
                        break;
                    case 5:
                        d = (volts - 4) * 0x10000 / 16;
                        break;
                    case 6:
                        d = (volts) * 0x10000 / 20;
                        break;
                    case 7:
                        d = (volts) * 0x10000 / 24;
                        break;
                }
                o = (int)d;
            }
            catch (Exception e)
            {
                System.Windows.MessageBox.Show(e.ToString());
            }
            return o;
        }

        int Ptob(decimal volts)
        { int o = 0;
            decimal d = 0;
            try
            {
                d = volts * ratio * 4;
                o = (int)d;
                return o;
            }
            catch (Exception e)
            {
                System.Windows.MessageBox.Show(e.ToString());
            }
            return o;
        }
    }
}


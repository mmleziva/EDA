
// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef UART1DRV_H
#define	UART1DRV_H
#include <xc.h> // include processor files - each processor file is guarded. 
#define BAUDRATE 115200
//#define BRGVAL   ((FCY/BAUDRATE)/4)-1 
//#define BRGVAL   ((FCY/BAUDRATE)/4)+1 
#define BRGVAL   127    //71//((FCY/BAUDRATE)/4)-1 
#define BUFMAX 64
typedef struct 
{
	unsigned Rec :1;  
    unsigned Relo:1;
    unsigned Edc:1;
    unsigned Edlo:1;    
    unsigned Creq:1;
    unsigned Loreq:1;  
	unsigned Ctra:  1;
    unsigned Lotra: 1;
  	unsigned Hireq: 1;
    unsigned Golo: 1;
	
}uf;
extern uf UF;
extern volatile signed int ni1,ni21,nilo,Nstr;
extern char bufout[],bufin[],bufm2[],buflo[],*pbufout,*pbufin,*pbufico,*pbufm2,*pbuflo,*cwbuf,*pbuflim;
extern unsigned int lenght;
void cfgUart1(void);
void startU1tr(unsigned int len);
void startU21tr(void);

#endif	/* UART1DRV_H */


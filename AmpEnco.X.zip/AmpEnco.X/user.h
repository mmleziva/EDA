#include <xc.h>
//#include <p33Exxxx.h>
//#include "ezbl.h"   //t
#ifndef ENCONV_H
#define ENCONV_H

#define FCY      (((7370000*36)/16)/2)

#define LED101 _RA10
#define LED102 _RA7
#define LED103 _RB14
#define LED104 _RB15

#define LED4 _RA2
#define LED6 _RA3
#define LED5 _RA8
#define LED7 _RB4

#define PGD _RB5
#define PGC _RB6
#define ALARM _RB9



typedef struct 
{
    unsigned SOK:1;
    unsigned PRE:1;
    unsigned POST:1;
    unsigned FRD:1;
    unsigned SERR:1;
    unsigned LISTEN:1;
    unsigned WRITE:1;
    
}flags;

typedef union
{
 struct
 {
    unsigned char L;
    unsigned char H; 
 };
 unsigned int W; 
}whl;

typedef union
{
 struct
 {
    unsigned int L;
    unsigned int H; 
 };
 unsigned long int UD; 
 signed long  int D; 
}dhl;

typedef union
{
 struct
 {
    unsigned CVR: 4;
    unsigned CREF:  1;
   
 };
 struct
 {
    unsigned char L;
    unsigned char H; 
 };
 unsigned int W; 
}compar;



#endif  //ENCONV_H

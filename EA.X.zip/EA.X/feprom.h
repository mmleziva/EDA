
#ifndef FEPROM_H
#define	FEPROM_H
#include "libpic30.h"
#define FLASHI 32
#define FLASHPOLY 4
void InitFEPROM(long int *da,long int *ta);  //Init FEPROM
void WriteFEPROM(long int *da,long int *ta);  //Init FEPROM

#endif	/* FEPROM_H */

// UART Configuration
#include "user.h"
#include "uart1Drv.h"
#include "uart2Drv.h"
#include <string.h>
#define DE    _LATB11

char bufot2[BUFMAX+1],bufir2[BUFMAX+1], *pbufir2, *pbufot2,buflo[BUFMAX+1];
volatile signed int ni2, no2, bci2;

void cfgUart2(void)
{
    _TRISB11=0;               //enable DE output
    _CNPUB12= 1;              //pull up receive input   
    RPINR19bits.U2RXR = 44; // U2RX on RPI44
    RPOR4bits.RP42R = 0x03; // U2TX on RP42
    pbufir2=&bufir2[0];
    pbufot2=&bufot2[0];
   
    bufir2[BUFMAX]=0;
    bufot2[BUFMAX]=0;
	U2MODEbits.STSEL = 0;			// 1-stop bit
	U2MODEbits.PDSEL = 0;			// No Parity, 8-data bits
	U2MODEbits.ABAUD = 0;			// Autobaud Disabled
    U2MODEbits.BRGH =  1;//t
	U2BRG = BRGVAL;					// BAUD Rate Setting for 115200


	//********************************************************************************
	//  STEP 1:
	//  Configure UART for DMA transfers
	//********************************************************************************/
	U2STAbits.UTXISEL0 = 1;		// interrupt after transfer completing
	U2STAbits.UTXISEL1 = 0;		//!t    interrupt after transfer to TSR              
	U2STAbits.URXISEL  = 0;			// Interrupt after one RX character is received

	//********************************************************************************
	//  STEP 2:
	//  Enable UART Rx and Tx
	//********************************************************************************/
	U2MODEbits.UARTEN   = 1;		// Enable UART
	U2STAbits.UTXEN     = 1;		// Enable UART Tx
    IEC4bits.U2EIE = 1;             //enable error com interrupt
    _U2RXIE=1;				//enable receiver interrupt
    _U2TXIE=1;
    _U2TXIF=0;
    _U2RXIF=0;

}

void startU2tr(void)//start transmit of UART1->USB data for other card to UART2->RS485
{
    if(UF.Loreq && !UF.Lotra && !UF.Golo)
    {
            UF.Lotra=1;
            UF.Loreq=0;
            size_t lengo2= strlen(buflo);
            //memcpy(bufot2,buflo,(nilo +1));     
            memcpy(bufot2,buflo,lengo2);
            pbufot2= &bufot2[0];
            DE=1;
            U2TXREG=*pbufot2; 
    }
}

// receive data ISR
void __attribute__((interrupt, no_auto_psv)) _U2RXInterrupt (void)
{
 UF.Golo=1; //receiving flag
 if(U2STAbits.OERR)U2STAbits.OERR=0;		// Enable UART Tx
 bci2= U2RXREG & 0xff;
 _U2RXIF=0;
 if(bci2==0xff)
     *pbufir2=0;
 else if(((bci2 ==' ')||(bci2=='\n')))
     *pbufir2=0;
 else *pbufir2=bci2;
 if((ni2>=(BUFMAX-1))||(*pbufir2==0))
 {              //receiving finished
   pbufir2=&bufir2[0];
   if(!UF.Edlo)
   {    
    ni2++;
    memcpy(bufm2,bufir2,ni2);
    ni21=ni2;
    pbufm2=&bufm2[0];
    UF.Golo=0;	//!t  
    UF.Relo=1;	  
  }
   ni2=0;
 }
 else
 {
  pbufir2++;
  ni2++;
 } 
 return;
}


void __attribute__((interrupt, no_auto_psv)) _U2TXInterrupt (void)
{
   _U2TXIF=0; 
   if((*(pbufot2) != 0)&& (no2 < (BUFMAX-1)))
   {            //transmition continue
    no2++;
    pbufot2++;
    U2TXREG= *pbufot2;
   } 
   else {           //transmition finished
          no2=0;        
          pbufot2=&bufot2[0];
          UF.Lotra =0;
          DE=0;
          LED101=0;     //t
         }         
}


void __attribute__ ((interrupt, no_auto_psv)) _U2ErrInterrupt(void)
{
    	IFS4bits.U2EIF = 0; // Clear the UART2 Error Interrupt Flag 
        U2STAbits.OERR  = 0;        
}



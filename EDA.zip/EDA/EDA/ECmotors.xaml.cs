﻿using System;
using System.Globalization;
using System.Threading;
using System.ComponentModel;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace EDA
{
    /// <summary>
    /// Interakční logika pro ECmotors.xaml
    /// </summary>
    public partial class ECmotors : Window
    {
        short  x, y;
        string strm, stra;
        DispatcherTimer dispatcherTimerE = new DispatcherTimer();
        public ECmotors()
        {
            InitializeComponent();
           //   Thread.CurrentThread.CurrentCulture.NumberFormat.NumberDecimalSeparator = ".";
            Thread.CurrentThread.CurrentCulture = CultureInfo.CreateSpecificCulture("en-GB");
          //  NumberFormatInfo nfi = new NumberFormatInfo();
          //  nfi.NumberDecimalSeparator = ".";

        }

        private void iniTimerA()
        {
            dispatcherTimerE.Tick += new EventHandler(dispatcherTimerA_Tick);
            dispatcherTimerE.Interval = new TimeSpan(0, 0, 0, 0, 200);
            dispatcherTimerE.Start();
        }

        private void ECmotorY_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            try
            {
                /*
                string test = "3.142527";//t
                Decimal ftest = Decimal.Parse(test);//t 
                test = "3.142527";//t
                Convert.ToDecimal(test);
                */
                y = (short)ECmotorY.Value;
                string sty = "y" + y.ToString();
                ser.serialWrite(sty);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void ECmotorX_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            try
            {
                x = (short)ECmotorX.Value;
                string stx = "x" + x.ToString();
                ser.serialWrite(stx);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }


        private void dispatcherTimerA_Tick(object sender, EventArgs et)
        {
            
            try
            {
                if (ser.serial.IsOpen && (ser.inserad.Count > 0))
                {
                    strm = ser.inserad.Dequeue();
                    if (strm != "")
                    {
                        stra = strm.Remove(1);
                        strm = strm.Remove(0, 1);
                        switch (stra)
                        {
                            case "X":
                                
                                break;
                            case "Y":
                                
                                break;
                            

                            default: break;
                        }

                    }
                }


            }
            catch (Exception e)
            {
                System.Windows.MessageBox.Show(e.ToString());

            }

        }
    }
}


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <libq.h>
#include "uart1Drv.h"
#include "uart2Drv.h"
#include "user.h"



dhl steps;
char al,la;
int n,m,NP,kn;
long int *inkr,*voltr;//t
unsigned int ax;
unsigned int lenght;
void interf(void)
{
        if(UF.Rec)        //USB->UART1 data from computer has been received
        {
            UF.Rec=0;
            UF.Edc=1;
            al= bufin[0];//t
      //      lenght =0;
            pbuflim= bufout+ BUFMAX-12; 
            switch(al)
            {
                case 'o':               // position command received
                    //if(cwbuf[1] >= '0')
                    // n=atoi(&cwbuf[1]);//t
                    //else
                    {
                    // bufout[0]='O';
                     steps.H=POS1CNTH;
                     steps.L=POS1CNTL;
                     lenght = sprintf(bufout,"O%ld",steps.D)+1;
           //          UF.Creq=1;
                    }
                    break;
                case 'v':                   // voltage command received
                    if(bufin[1] >= '0')
                    {
                     bufout[1]=0;
                     voltr[m]=atoi(&bufin[1]);//t
                     m++;
                    } 
                    else
                    {
                     }
                    break;
                case 'p':       
         //           bufout[0]='P';// position command received
                    if(bufin[1] >=  '0')
                    {
                     bufout[1]=0;
                     inkr[m]=atoi(&bufin[1]);//t   
                    }
                    else
                    {
                      pbufout=bufout;
                      for(n=0;n<NP;n++)
                      {
                        ax=(unsigned int)inkr[n];
                        kn= sprintf(pbufout,"P%u",ax);
                        pbufout += kn;
                        pbufout++;    
                        ax=(unsigned int)voltr[n];
                        kn= sprintf(pbufout,"V%u",ax);
                        pbufout += kn;
                        pbufout++;  
                        if(pbufout >= pbuflim)
                            break;
                      }
                      *pbufout='S';
                      pbufout++;
                      *pbufout=0;
                      pbufout++;
                      lenght = pbufout-bufout;
                                          }
                    break;
                case 's':       
                    bufout[0]='S';// position command received  
                    bufout[1]=0;
                    NP=m;
                    m=0;
                    lenght=2;
                    UF.Creq= 1;
                    break;                 
                default:
                {
                    if((al >= 'a')&&(al <= 'z'))
                     nilo=ni1;
                     memcpy(buflo,bufin,nilo); 
                     UF.Loreq=1;   
                }                
            }  
            UF.Edc=0;
         }
         if(UF.Relo)
         {
          UF.Relo=0;
          la=bufm2[0];
          if(isupper(la))
          {
              UF.Hireq=1;    
          }
          else
          if(islower(la))
          {
            switch(la)
            {
                LED101=1;//t
                case 'o':               // position command received
                    //if(cwbuf[1] >= '0')
                    // n=atoi(&cwbuf[1]);//t
                    //else
                    {
                     buflo[0]='O';
                     steps.H=POS1CNTH;
                     steps.L=POS1CNTL;
                     sprintf(&buflo[1],"%ld",steps.D);
                     UF.Loreq=1;
                    }
                    break;
                 default:
                {                    
                }                
            }              
          }
  
         }
  //       if(lenght>0)
  //       {
            startU1tr(lenght);   //start transmit of this card data to UART1->USB 
            lenght=0;
   //      }

    //     startU21tr();  //start  transmit of UART2->RS485 received data to UART1->USB
    //     startU2tr();   //start transmit of UART1->USB data for other card to UART2->RS485
}

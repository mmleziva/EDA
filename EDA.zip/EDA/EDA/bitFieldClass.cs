﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDA
{
    public class bitField
    {
        public UInt16[] A;
        public int[] sh;
        public int L;
        public  bitField(int[] shf)//constructor with arguments of  numbers of bit that sum is 16.
        {
            sh = shf;
            L = sh.Length;
            A = new UInt16[L]; 
        }
        public void WtoA(UInt16 B)//make bit field A from 16bit word W
        {
            int i, k, shift;        
            for (k = 0; k < L; k++)
            {
                shift = sh[k];
                A[k] = 0;
                for (i = 0; i < shift; i++)
                {
                    A[k] <<= 1;
                    if ((B & 0x8000) != 0) A[k] |= 1;
                    B <<= 1;
                }
            }           
        }
        public UInt16 AtoW()   //make  16bit word W  from 16bit field A
        {
            int i, k, shift;            
            UInt16 B = 0;
            UInt16 AK;
            for (k = (L - 1); k >= 0; k--)
            {
                shift = sh[k];
                AK = A[k];
                for (i = 0; i < shift; i++)
                {
                    B >>= 1;
                    if ((AK & 1) != 0) B |= 0x8000;
                    AK >>= 1;
                }
            }
            return B;
        }

    }

}

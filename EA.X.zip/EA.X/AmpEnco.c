/*
 * File:   enconv.c
 * Author: root
 *
 * Created on 12. listopadu 2016, 23:08
 */


//#include <xc.h>
#include "user.h"
#include "analog.h"
#include "qei.h"
#include "SPI.h"
//#include "mulib.h"
#include "uart1Drv.h"
#include "uart2Drv.h"
#include "interf.h"
#include <stdio.h>
#include <stdlib.h>

//#define NMAX 9

#pragma config PWMLOCK=OFF
#pragma config JTAGEN = OFF
#pragma config ICS=PGD2
#pragma config FNOSC = FRCPLL
//#pragma config FNOSC = FRC      //!t
#pragma config IESO = OFF
#pragma config OSCIOFNC = ON
#pragma config FWDTEN = OFF
#pragma config GWRP = OFF
#pragma config GCP = OFF
/*
_FICD(ICS_PGD2 & JTAGEN_OFF)                                                // Debug using PGEC1 and PGED1, turn off JTAG to recover I/O pins
_FPOR(ALTI2C1_OFF & ALTI2C2_OFF & WDTWIN_WIN75)                             // Use primary I2C1 and I2C2 pin mappings, set watchdog window to 75% (not important in non-window mode, but included for completness)
_FWDT(WDTPOST_PS2048 & WDTPRE_PR32 & PLLKEN_OFF & WINDIS_OFF & FWDTEN_OFF)  // ~2048ms timeout when watchdog is turned on in software (not forced on in hardware), continue executing from original clock before PLL locks on clock switch, use ordinary (non-windowed) Watchdog Timer mode
_FOSC(POSCMD_NONE & OSCIOFNC_ON & IOL1WAY_OFF & FCKSM_CSECMD)               // No primary oscillator, recover OSC2 pin as GPIO, allow multiple PPS remappings, enable clock switching but disable fail safe clock monitor
_FOSCSEL(FNOSC_FRCPLL & IESO_ON)                                            // Start with FRC, then auto-switch to FRC+PLL when PLL locks
_FGS(GWRP_OFF & GCP_OFF)     
*/

#define PLL 63
#define HOME _RB14

extern void __attribute__((interrupt, no_auto_psv)) _U2RXInterrupt (void);

extern flags Flags;
extern char bufout[],*pbufout;


struct {
    unsigned SW1A: 1;
    unsigned SW1F: 1;
    unsigned SW1L: 1;
    unsigned SW1FL:1;
    unsigned HSW1: 1;
    unsigned SW2A: 1;
    unsigned SW2F: 1;
    unsigned SW2L: 1;
    unsigned SW2FL:1;
    unsigned HSW2: 1;
    unsigned CCW: 1;
}F;

extern uf UF;
long int dla,clc,claold=0;//t
dhl ala,cla;
int k,ui,sect;
signed int douta;
int *pread,iread, result;
int r;
float fa;
float af;
int NMAX;
float slope[FLASHI];


void initIO(void)
{
     ANSELA=ANSELB=ANSELC=0;//t
     
    _TRISA10= 0;     //enable LED101
    _TRISA7= 0;     //enable LED102
    _TRISB14= 0;     //enable LED103
 //   _TRISB15= 0;    //enable LED104
    
    _TRISA2= 0;    //enable LED4
    _TRISA3= 0;    //enable LED6
    _TRISA8= 0;    //enable LED5
    _TRISB4= 0;    //enable LED7
    _CNPUB9= 1;     //alarm pull up
  //  CNENBbits.CNIEB9=1;// ALARM inputchange int
   // CNENBbits.CNIEB5=1;// prog. data change inp.//t
   // CNENBbits.CNIEB6=1; // prog. clock change inp.//t
    _CNIF=0;
  //  IEC1bits.CNIE= 1;
    IEC1bits.CMIE= 1;
    /*
    F.SW1A=SW1;     //extern switches init
    F.SW1L=F.SW1A; F.SW1F=F.SW1A; F.SW1FL=F.SW1A;
    F.HSW1=0;
    F.SW2A=SW2;	//!t
    F.SW2L=F.SW2A; F.SW2F=F.SW2A; F.SW2FL=F.SW2A;
    F.HSW2=0;
     */ 
}

//Init T1 timer				// input filter timer(also for  scanning coordinates samples)
void initT1(void)
{
 TMR1 = 0;
 PR1 = 1000;				//1000pulses divide 20kHz  to 20Hz
 T1CONbits.TCKPS = 3;		//256   PRESCALLER 
 //T1CONbits.TCKPS = 0;		//1   PRESCALLER 
 T1CONbits.TON = 1;		// turn on timer 1 
 _T1IF=0;
} 

//Init T2 timer				// input filter timer(also for  scanning coordinates samples)
void initT2(void)
{
 TMR2 = 0; 
 PR2 = 0X1FFF;				//1000pulses divide 20kHz  to 20Hz
 T2CONbits.TCKPS = 3;		//256   PRESCALLER 
 T2CONbits.TON = 1;		// testturn on timer 1 
 _T2IF=0;
} 

//Init T3 timer				// input filter timer(also for  scanning coordinates samples)
void initT3(void)
{
 TMR3 = 0;
 //PR3 = 1000;				//1000pulses divide 20kHz  to 20Hz
 PR3 = 0x0fff;				//test
 T3CONbits.TCKPS = 3;		//256   PRESCALLER 
 T3CONbits.TON = 1;		// turn on timer 1 
 _T3IF=0;
} 

unsigned int countdac(void)
{
 unsigned int dret=0;   
 int d;
 sect=0;
 cla.L= POS1CNTL; 
 cla.H= POS1CNTH;
 //if(cla.D < claold) F.CCW=1;                        //set CCW direction of encoder
// else if(cla.D > claold) F.CCW=0;                   //set CW direction of encoder
// claold= cla.D;
 clc=cla.D;
 while((clc >= inkr[sect])&& (sect<NP))                         //search actual position sector of encoder
 {
     sect++;
 }
 
 //if((dinkr[sect] !=0)&&(!DIP1 || !F.CCW))           //enable new calculation of output
 {    
  if((sect==0)||(sect==NP))
    dret=0; 
  else                              //in front of output peak
  {
     d= (unsigned int)(clc - inkr[sect-1]);
     douta= (signed int)(slope[sect-1]*d);  
     dret= voltr[sect-1] + douta;
  }  
 } 
 
 //if((sect==0)||(sect==NMAX))
 //  dret=0;   
     /*
 else if((inkr[sect] > inkr[sect-1])&&(!DIP1 || !F.CCW))           //enable new calculation of output
 {
     d= (unsigned int)(clc - inkr[sect-1]);
     douta= (signed int)(slope[sect-1]*d);  
     dret= voltr[sect-1] + douta; 
 } 
       */
 return dret ;
}

/*
int homecomp(void)
{
    if(comp.CREF)
    {
     HOME= (ADC1BUF0 > (comp.CVR<<6));
    }
    else
        HOME= (ADC1BUF0 > ADC1BUF1 );
 //    _AD1IF=0;//t
    LED5= HOME;//t
    return ADC1BUF1;
}
*/

void genslope(void)
{ float fd;
    if((NP > 1) && (NP < NUMAX))
    {
           for(ui=0; ui< NP-1; ui++)
            { fd= (float)(inkr[ui+1]-inkr[ui]);
               if(fd !=0)
               {
                      af= (float)(voltr[ui+1]-voltr[ui])/fd;
                      slope[ui]= af;
               }
               else
                      slope[ui]=0;
            }
    }
}


int main(void) {
    /*  // EZBL_ForwardBootloaderISR |= 0x00000006;
    //    // Optionally take over the UART2 module interrupts if we want to disable 
//    // bootloader ISR handling and use our Application defined ones instead.
    {
        unsigned long isrForwardMaskBit;
        EZBL_GetSymbol(isrForwardMaskBit, EZBL_FORWARD_MASK_U2RX);
        EZBL_ForwardBootloaderISR |= isrForwardMaskBit;
        EZBL_GetSymbol(isrForwardMaskBit, EZBL_FORWARD_MASK_U2TX);
        EZBL_ForwardBootloaderISR |= isrForwardMaskBit;
    }
     */ 
     TMR1=0;     //pause
    _T1IF=0;
    PR1=0xffff;
    T1CONbits.TON = 1;	
    while(!_T1IF)
    _T1IF=0;
    _PLLPOST=0;  //1;
    _PLLDIV= PLL; //70;
    _PLLPRE=0;
     _NOSC=7;    //frc
    initIO();
    InitFEPROM((long int * )inkrpar,(long int *) voltrpar);  //Init FEPROM
    initComp();
    initQei();
    initSPI();
    DAC(CONTROL,*dacontrol);
//    initDAC(); 
    initAdc1();
    set_encod(*pencod); 
    NP=(int)inkrpar[0];
    genslope();
    initT1();
    initT2();
    initT3();
    cfgUart1();
    cfgUart2();
    while(1)
    {  
        __asm__("clrwdt");
         LED4= _C2OUT;
         LED6= _C1OUT;
        /*
        if(_CNIF)
        {
            _CNIF=0;           
            DAC(READ,READSTATUS);//read status
        }     
         * */  
 //        homecomp();//t
         dao=countdac();
         readreg=DAC(DATA,dao);
        /*
        if(readreg == (READCONTROL + 0x80))
        {
           bufout[0]='C'; 
           iread=*pread;
           sprintf(&bufout[1],"%u",iread);
           UF.Sedat=1; 
        }
        if(readreg == (READCONFIG + 0x80))
        {
           bufout[0]='F'; 
           iread=*pread;
           sprintf(&bufout[1],"%u",iread);
           UF.Sedat=1; 
        }
        else if(readreg == (READSTATUS + 0x80))
        {
           bufout[0]='A'; 
           iread=*pread;
           sprintf(&bufout[1],"%u",iread);
           UF.Sedat=1; 
        }
         */ 
     //   prepare(DATA,dao);        
        interf();
        if(UF.Creq)
        {
            UF.Creq=0;
            *inkrpar=NP;
            WriteFEPROM((long int * )inkrpar,(long int * ) voltrpar);//t
            /*
            for(ui=0; ui< NP-1; ui++)
            {
                      af= (float)(voltr[ui+1]-voltr[ui])/(float)(inkr[ui+1]-inkr[ui]);
                      slope[ui]= af;
            }
             * */
            genslope();
        }
        if(_T3IF)
        {
          _T3IF=0;
     
        }//t
         
         //F.HSW1=0;
         //F.SW1A= SW1;    			//prepis stavu tlacitka
         //if(F.SW1A == F.SW1L)F.SW1F= F.SW1A;		// filtrace
         //if(!F.SW1FL && F.SW1F)F.HSW1=1;		// hrana
         //F.SW1L=F.SW1A;				//pamet stavu pro priste
         //F.SW1FL=F.SW1F;
         //if(F.HSW1)
            /* 
         {         
          ala.L= POS1CNTL; 
          ala.H= POS1CNTH; 
          if((ala.D < 0x1000000) && (ala.D > -0x1000000))
          {        
           if(((k==0)&&(ala.D >0))||((k>0) && ((dla= ala.D- inkr[k-1])>0)&& (dla< 0x10000)))
           {
            inkr[k]= ala.D;
            k++;
            if(k==9)
            {
              k=0;
              PR2=0x7fff;   
              NMAX=9;
              inkrpar[0]=NMAX;
              WriteFEPROM(inkrpar, voltrpar);//t  
              for(ui=0; ui<8; ui++)
                slope[ui]= (float)(voltr[ui+1]-voltr[ui])/(float)(inkr[ui+1]-inkr[ui]); 
            } 
            else
            PR2=0x0fff;      
          //  LED1= 1;
            TMR2 = 0;
            T2CONbits.TON = 1;                  
           } 
          }
         }
         if(_T2IF)
         {
           _T2IF=0;
          // LED1= 0;         
           T2CONbits.TON = 0;
         }     
         
         //F.HSW2=0;
         //F.SW2A= SW2;    			//prepis stavu tlacitka
         //if(F.SW2A == F.SW2L)F.SW2F= F.SW2A;		// filtrace
         //if(!F.SW2FL && F.SW2F)F.HSW2=1;		// hrana
         //F.SW2L=F.SW2A;				//pamet stavu pro priste
         //F.SW2FL=F.SW2F;
         //if(F.HSW2)
         //{
         // LED2= !LED2;
         //} 
           
        }  
              */ 
        /*
        if(UF.K)
        {
            UF.K=0;
            char al= cwbuf[0];//t
            switch(al)
            {
                case 'w':               // position command received
                    //if(cwbuf[1] >= '0')
                    // n=atoi(&cwbuf[1]);//t
                    //else
                    {
                     bufout[0]='W';
                     steps.H=POS1CNTH;
                     steps.L=POS1CNTL;
                     sprintf(&bufout[1],"%ld",steps.UD);
                     UF.Sedat=1;
                    }
                    break;
                case 'n':               // position command received
                    if(cwbuf[1] >= '0')
                     n=atoi(&cwbuf[1]);//t
                    else
                    {
                     bufout[0]='N';
                     sprintf(&bufout[1],"%d",n);
                     UF.Sedat=1;
                    }
                    break;
                case 'm':                   // number of polyline peaks received
                    if(cwbuf[1] >= '0')
                     NMAX=atoi(&cwbuf[1]);//t
                    else
                    {
                     bufout[0]='M';
                     sprintf(&bufout[1],"%d",NMAX);
                     UF.Sedat=1;
                    }
                    break;
                case 'r':                   // ratio encoder pulses/m(rev)
                    if(cwbuf[1] >= '0')
                     voltrpar[0]=atoi(&cwbuf[1]);//t
                    else
                    {
                     bufout[0]='R';
                     rat= (unsigned int)voltrpar[0];
                     sprintf(&bufout[1],"%d",rat);
                     UF.Sedat=1;
                    }
                    break;
                case 'v':                   // voltage command received
                    if(cwbuf[1] >= '0')
                    {
                     voltr[m]=atoi(&cwbuf[1]);//t
                     m++;
                    } 
                    else
                    {
                     bufout[0]='V';
                     ax=(unsigned int)voltr[n];
                     sprintf(&bufout[1],"%u",ax);
                     UF.Sedat=1;
                    }
                    break;
                case 'p':                   // position command received
                    if(cwbuf[1] >=  '0')
                     inkr[m]=atoi(&cwbuf[1]);//t   
                    else
                    {
                     bufout[0]='P';
                     ax=(unsigned int)inkr[n];
                     sprintf(&bufout[1],"%u",ax);
                     UF.Sedat=1;
                    }
                    break;
                   case 'f':                    // control command received
                    if(cwbuf[1] >=  '0')
                    {
                     dacont=atoi(&cwbuf[1]);//t                      
                     prepare(CONFIG ,dacont);
                    }
                    else
                    {                                       
                     prepare(READ,READCONFIG);//command for read control register 
                    }
                    break; 
                    case 'c':                    // control command received
                    if(cwbuf[1] >=  '0')
                    {
                     dacont=atoi(&cwbuf[1]);//t                      
                     prepare(CONTROL ,dacont);
                    }
                    else
                    {                                       
                     prepare(READ,READCONTROL);//command for read control register 
                    }
                    break; 
                   case 's':                   
                    inkrpar[0]=m;
                    WriteFEPROM(inkrpar, voltrpar);//t   
                    for(ui=0; ui< m-1; ui++)
                    {
                      af= (float)(voltr[ui+1]-voltr[ui])/(float)(inkr[ui+1]-inkr[ui]);
                      slope[ui]= af;
                    }
                    PR2=0x7fff;      
                 //   LED1= 1;
                    TMR2 = 0;
                    T2CONbits.TON = 1;
                    NMAX=m;
                    m=0;
                    break;
            }           
         }
        if(UF.Sedat && !UF.R)
        {
            UF.R=1;
            UF.Sedat=0;
            pbufout=&bufout[0];
            U1TXREG=bufout[0]; 
        }
          */
    }
    return 0;
}

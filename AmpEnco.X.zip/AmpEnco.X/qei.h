// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef QEI_H
#define	QEI_H

#include <xc.h> // include processor files - each processor file is guarded.  

#endif	/* QEI_H */

extern void initQei(void);
#include <xc.h>
#include "user.h"

void initQei(void)
{
    RPINR14bits.QEA1R= 56;//37//36;
    RPINR14bits.QEB1R= 57;//38//41;
    RPINR15bits.INDX1R= 36;//36//37;  
    QEI1CONbits.QEIEN=1;//ENABLE qei
    POS1CNTH=0;
    POS1CNTL=0;
    
}
/*
void __attribute__((interrupt, no_auto_psv)) _CNInterrupt(void)
{    
    IFS1bits.CNIF  = 0;			// Clear interrupt   
    LED4= ALARM;
    LED6= LED7; 
    LED5= PGC; 
}
 * */
